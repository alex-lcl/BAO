#------------------------------------------------------------------------------------
# SF - février 2021
# Ce programme convertit un fichier issu de udPipe1 au format d'une base annotée pour iTrameur
# perl udpipe-2-iTrameur.pl FILE-TALISMANE
# le fichier résultat créé s'appelle iTrameur-FILE-UDPIPE.txt
#------------------------------------------------------------------------------------
use File::Basename;
use utf8;
my $positioncouranteA=0;
my $nbphraseA=1;
my %dicoID=();
my %dictionnairedesparties=();
my $partieencours="";
#------------- recréation des identifiants --------
open(RHAP,"<:encoding(utf-8)",$ARGV[0]);
while (my $ligne=<RHAP>) {
	$ligne=~s/\r//g;
	next if ($ligne=~/^$/);
	#print "A : ",$ligne;
	#my $aaa=<STDIN>;
	if ($ligne=~/^# text =/) {
		if  ($ligne=~/<([^=]+)=([^>]+)>/) {
			while (($ligne!~/^# sent_id/) && (!eof(RHAP))) {
				$ligne=<RHAP>;
				#print "A1 : ",$ligne;
			}	
		}
		if  ($ligne=~/<\/([^>]+)>/) {
			while (($ligne!~/^# sent_id/) && (!eof(RHAP))) {
				$ligne=<RHAP>;
				#print "A2 : ",$ligne;
			}	
		}
	}
	if ($ligne=~/^1\t/) {
		my $Text_ID=$nbphraseA;
		if (!(exists($dictionnairedesparties{$Text_ID}))) {
			if ($partieencours ne "") { 
				if ($positioncouranteA > 0) {
					$positioncouranteA++;
					$positioncouranteA++;
				}
			};
			$partieencours=$Text_ID;
			#----------- integration other parties ---------------------
		}
		else {
			if ($positioncouranteA > 0) {
				$positioncouranteA++;
				$positioncouranteA++;
			}
		}
	}
    if ($ligne=~/^([0-9]+)\t([^\t]+)?\t([^\t]+)?\t([^\t]+)?\t([^\t]+)?\t([^\t]+)?\t([^\t]+)?\t([^\t]+)?\t([^\t]+)?\t([^\t]+)?/) {
		my $pos=$1;
		my $f=$2;
		my $l=$3;
		my $c=$4;
		my $xx1=$5;
		my $xx2=$6;
		my $cible=$7;
		my $rel=$8;
		my $xx3=$9;
		my $xx4=$10;
		if ($pos==1) {
			$nbphraseA++;
		}
		$positioncouranteA++;
		my $cle=$nbphraseA."_".$pos;
		$dicoID{$cle}=$positioncouranteA;
		$positioncouranteA++; ## pour les espaces entre les items
	}
}
close(RHAP);

#------------- recréation de la trame --------
my %dicodespartiesencours=();
my %dictionnairedesautresparties=();
my %dicoOrdreDesParties=();
my $ordredesparties=1;

$positioncouranteA=0;
$nbphraseA=1;
$partieencours="";
%dictionnairedesparties=();

open(RHAP,"<:encoding(utf-8)",$ARGV[0]);
my($filename, $dirs, $suffix) = fileparse($ARGV[0]);
open(RHAPITRAMEUR,">:encoding(utf-8)","iTrameur-$filename.txt");
#---------------------------------------------------------------------
while (my $ligne=<RHAP>) {
	next if ($ligne=~/^$/);
	$ligne=~s/\r//;
	#print "B : ",$ligne;
	#my $aaa=<STDIN>;
	chomp $ligne;
	#----------------------------------------
	# recherche des balises
	if ($ligne=~/^# text =/) {
		if  ($ligne=~/<([^=]+)=([^>]+)>/) {
			my $partition=$1;
			my $part=$2;
			$part=~s/"//g;
			my $PP=$partition."//".$part;
			#print "PP : $PP \n";
			$dicodespartiesencours{$partition}=$part;
			if ($positioncouranteA == 0) {
				push(@{$dictionnairedesautresparties{$PP}},1);
			}
			else {
				push(@{$dictionnairedesautresparties{$PP}},$positioncouranteA+3);
			}
			
			if (!exists($dicoOrdreDesParties{$PP})) {
				$dicoOrdreDesParties{$PP}=$ordredesparties;
				$ordredesparties++;
			}
			
			while (($ligne!~/^# sent_id/) && (!eof(RHAP))) {
				$ligne=<RHAP>;
			}
		}
		if  ($ligne=~/<\/([^>]+)>/) {
			my $partition=$1;
			my $part=$dicodespartiesencours{$partition};
			my $PP=$partition."//".$part;
			#print "PPf : $PP \n";
			if ($positioncouranteA == 0) {
				push(@{$dictionnairedesautresparties{$PP}},1);
			}
			else {
				push(@{$dictionnairedesautresparties{$PP}},$positioncouranteA+2);
			}
			while (($ligne!~/^# sent_id/) && (!eof(RHAP))) {
				$ligne=<RHAP>;
			}
		}	
	}
	#----------------------------------------
	if ($ligne=~/^1\t/) {
		my $Text_ID=$nbphraseA;
		if (!(exists($dictionnairedesparties{$Text_ID}))) {
			if ($partieencours ne "") { 
				if ($positioncouranteA > 0) {
					$positioncouranteA++;
					print RHAPITRAMEUR "$positioncouranteA\tdelim\t§\tDELIM\t§\t_\t_\t_\n";
					$positioncouranteA++;
					print RHAPITRAMEUR "$positioncouranteA\tdelim\t \tBLANK\tBLANK\t_\t_\t_\n";
				}
				#----------- integration other parties ---------------------
				#-----------------------------------------------------------
				push(@{$dictionnairedesparties{$partieencours}},$positioncouranteA);
			};
			if ($positioncouranteA == 0) {
				push(@{$dictionnairedesparties{$Text_ID}},1);
			}
			else {
				push(@{$dictionnairedesparties{$Text_ID}},$positioncouranteA+1);
			}
			$partieencours=$Text_ID;
			#----------- integration other parties ---------------------
		}
		else {
			if ($positioncouranteA > 0) {
				$positioncouranteA++;
				print RHAPITRAMEUR "$positioncouranteA\tdelim\t§\tDELIM\t§\t_\t_\t_\n";
				$positioncouranteA++;
				print RHAPITRAMEUR "$positioncouranteA\tdelim\t \tBLANK\tBLANK\t_\t_\t_\n";
			}
		}
	}
    if ($ligne=~/^([0-9]+)\t([^\t]+)?\t([^\t]+)?\t([^\t]+)?\t([^\t]+)?\t([^\t]+)?\t([^\t]+)?\t([^\t]+)?\t([^\t]+)?\t([^\t]+)?/) {
		my $pos=$1;
		my $f=$2;
		my $l=$3;
		my $c=$4;
		my $xx1=$5;
		my $xx2=$6;
		my $cible=$7;
		my $rel=$8;
		my $xx3=$9;
		my $xx4=$10;
		
		if ($f eq "") {$f="_"};
		if ($l eq "") {$l="_"};
		if ($c eq "") {$c="_"};
		if ($xx1 eq "") {$xx1="_"};
		if ($xx2 eq "") {$xx2="_"};
		if ($rel eq "") {$rel="_"};
		if ($cible eq "") {$cible="_"};
		
		$f=~s/</&lt;/g;
		$f=~s/>/&gt;/g;
		$l=~s/</&lt;/g;
		$l=~s/>/&gt;/g;
		
		$f=~s/"/&quot;/g;
		#$f=~s/'/&apos;/g;
		$l=~s/"/&quot;/g;
		#$l=~s/'/&apos;/g;
		
		$rel=~s/:/_/g;
		#------------- DEPENDANCE ? -----------------
		if ($pos==1) {
			$nbphraseA++;
		}
		$positioncouranteA++;
		my $cle=$nbphraseA."_".$cible;
		my $id_DEP=$dicoID{$cle}; # attention remplacer les : par _
		my $rel2print=uc($rel)."(".$id_DEP.")";
		if (uc($rel) eq "ROOT") {$rel2print="ROOT"};
		if (uc($c) eq "PONCT") {
			print RHAPITRAMEUR "$positioncouranteA\tdelim\t$f\tPONCT\t$l\t_\t_\t_\n";
		}
		else {
			print RHAPITRAMEUR "$positioncouranteA\tforme\t$f\t$c\t$l\t$xx1\t$xx2\t$rel2print\n";
		}
		#------------- DELIMITEUR -------------------
		$positioncouranteA++;
		print RHAPITRAMEUR "$positioncouranteA\tdelim\t \tBLANK\tBLANK\t_\t_\t_\n";
	}
}
$positioncouranteA++;
print RHAPITRAMEUR "$positioncouranteA\tdelim\t§\tDELIM\t§\t_\t_\t_\n";
$positioncouranteA++;
print RHAPITRAMEUR "$positioncouranteA\tdelim\t \tBLANK\tBLANK\t_\t_\t_\n";
push(@{$dictionnairedesparties{$partieencours}},$positioncouranteA);
#--------------------------------------------------------
# impression des parties
# ATTENTION : il faut probablement les remettre en ordre...
#
foreach my $partie (sort {$dicoOrdreDesParties{$a} <=> $dicoOrdreDesParties{$b}} keys %dictionnairedesautresparties) {

    my @positions=@{$dictionnairedesautresparties{$partie}};
	$partie=~/([^\/]+)\/\/([^\/]+)/;
	my $partition=$1;
	my $part=$2;
	$part=~s/"//g;
	#print "PP : $PP \n";
	while (my ($deb,$fin)=@positions) {
		print RHAPITRAMEUR "PARTITION:$partition\tPARTIE:$part\tDEBUT:$deb\tFIN:$fin\n";
		shift @positions;
		shift @positions;
	}
}

foreach my $partie (keys %dictionnairedesparties) {

    my @positions=@{$dictionnairedesparties{$partie}};
    print RHAPITRAMEUR "PARTITION:TEXTE\tPARTIE:$partie\tDEBUT:$positions[0]\tFIN:$positions[1]\n";

}

close(RHAPITRAMEUR);
close(RHAP);
#---------------------------------------------
print "ATTENTION : ne pas oublier de faire un dos2unix sur le fichier resultat !!!!\n";
