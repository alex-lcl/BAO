
1. README UDPIPE 
================

via UDPipe 1 : http://ufal.mff.cuni.cz/udpipe/1
Manuel udpipe : https://ufal.mff.cuni.cz/udpipe/1/users-manual
Ressources utilisées ici disponibles à cette adresse : https://github.com/ufal/udpipe/releases/tag/v1.2.0  
Version en ligne pour voir les arbres : https://lindat.mff.cuni.cz/services/udpipe/

Pour lancer l'annotation, il faut disposer de l'outil et d'un modèle :

==> on dézippe l'archive dans un dossier : cette archive regroupe l'outil udpipe (il y a des versions pour différents OS) et un certain nombre de modèles de langue

Pour les autres langues, il convient de récupérer la ressource idoine : Universal Dependencies 2.5 Models: udpipe-ud2.5-191206 http://hdl.handle.net/11234/1-3131


On lance le programme ainsi :

udpipe --tokenize --tag --parse udpipe_model file  > result_udpipe

REMARQUE : si les données ont été présegmentées en phrase ajoutez : --tokenizer=presegmented

udpipe : choisir le programme adapté à son système
udpipe_model : modèle à utiliser. Dans l'archive, un seul modèle dispo (french...) dans le dossier modeles
file : le nom du fichier à parser



2. CONSEILS POUR LA MISE EN FORME DES DONNEES A PARSER PAR UDPIPE (AVANT DE RECREER UNE BASE POUR ITRAMEUR)
================================================================

1. Une phrase par ligne (dans ce cas ajouter --tokenizer=presegmented dans la commande) : optionnel mais conseillé... 

2. Isoler les balises : une par ligne sous la forme <PARTIE=VALEUR> (et </PARTIE>) : cf voir le fichier exemple dans l'archive : test_dormeur-balisageexplicite.txt
	
	dans le cas ou le texte est balisé, ajoutez  l'option au moment du parsage :  --tokenizer=presegmented

3. Parser les données avec udpipe comme indiqué supra

	exemple sur fichier de test : udpipe --tokenize --tokenizer=presegmented --tag --parse udpipe_model test_dormeur-balisageexplicite.txt  > test_dormeur-balisageexplicite.udpipe

4. Pour créer la base pour iTrameur : utiliser le programme udpipe-2-iTrameur_best.pl comme ceci :

    perl udpipe-2-iTrameur_best.pl test_dormeur-balisageexplicite.udpipe
	
	où test_dormeur-balisageexplicite.udpipe est le résultat produit par udpipe cf supra